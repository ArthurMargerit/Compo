#include "{{Facette_name}}.hpp"

//! Default constructor
{{Facette_name}}::{{Facette_name}}()
{

  return;
}

//! Copy constructor
{{Facette_name}}::{{Facette_name}}(const {{Facette_name}} &other)
{

  return;
}

//! Move constructor
{{Facette_name}}::{{Facette_name}}({{Facette_name}} &&other) noexcept
{

  return;
}


//! Destructor
{{Facette_name}}::~{{Facette_name}}() noexcept
{

  return;
}


//! Copy assignment operator
{{Facette_name}}& {{Facette_name}}::operator=(const {{Facette_name}} &other)
{

}

//! Move assignment operator
{{Facette_name}}& {{Facette_name}}::operator=({{Facette_name}} &&other) noexcept
{

}

