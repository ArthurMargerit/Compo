#pragma once

#include <cstdint>

typedef int64_t i64;
