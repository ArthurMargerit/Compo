#pragma once

#include <cstdint>

typedef int32_t i32;
