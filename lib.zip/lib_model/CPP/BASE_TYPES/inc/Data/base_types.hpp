#pragma once

#include "Data/Type_Char.hpp"
#include "Data/Type_String.hpp"
#include "Data/Type_i16.hpp"
#include "Data/Type_i32.hpp"
#include "Data/Type_i64.hpp"
#include "Data/Type_i8.hpp"
#include "Data/Type_ui16.hpp"
#include "Data/Type_ui32.hpp"
#include "Data/Type_ui64.hpp"
#include "Data/Type_ui8.hpp"