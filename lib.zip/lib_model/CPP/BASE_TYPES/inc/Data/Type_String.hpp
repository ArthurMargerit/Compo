#pragma once

#include <string>
#include <istream>
#include <ostream>

class String : public std::string {
public:
  String():std::string(""){}
  String(const char* a):std::string(a){}
};


std::ostream& operator<<(std::ostream& os, const String& c);
std::istream& operator>>(std::istream& is, String& c);

