#pragma once

#include <cstdint>

typedef uint32_t ui32;
