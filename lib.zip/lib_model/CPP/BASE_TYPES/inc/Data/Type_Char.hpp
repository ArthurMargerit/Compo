#pragma once
#include <istream>
#include <ostream>

typedef char Char;

std::ostream& operator<<(std::ostream& os, const Char& c);
std::istream& operator>>(std::istream& is, Char& c);
