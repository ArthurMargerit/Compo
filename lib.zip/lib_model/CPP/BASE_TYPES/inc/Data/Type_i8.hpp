#pragma once

#include <cstdint>

typedef int8_t i8;
