#pragma once

#include <cstdint>

typedef uint16_t ui16;
