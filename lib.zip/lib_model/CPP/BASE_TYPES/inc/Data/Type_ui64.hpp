#pragma once

#include <cstdint>

typedef uint64_t ui64;
