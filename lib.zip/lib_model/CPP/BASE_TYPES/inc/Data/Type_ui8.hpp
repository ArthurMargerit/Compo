#pragma once

#include <cstdint>

typedef uint8_t ui8;
