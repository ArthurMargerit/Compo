#pragma once

#include <cstdint>

typedef int16_t i16;
