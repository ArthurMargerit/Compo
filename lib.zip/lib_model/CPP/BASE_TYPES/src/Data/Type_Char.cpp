#include "Data/Type_Char.hpp"

std::ostream& operator<<(std::ostream& os, const Char& c)
{
  os.put('\'');

  if(' ' <= c && c < '~' && c != '\\' && c != '\'' )
    os.put(c);
  else{
    os.put('\\');
    switch(c){
    case '\'':
      os.put('\'');
      break;
        
    case '\\':
      os.put('\\');
      break;
        
    case '\a':
      os.put('a');
      break;
        
    case '\b':
      os.put('b');
      break;

    case '\f':
      os.put('f');
      break;

    case '\n':
      os.put('n');
      break;

    case '\r':
      os.put('r');
      break;

    case '\t':
      os.put('t');
      break;

    case '\v':
      os.put('v');
      break;
        
    case '\0':
      os.put('0');
      break;
      
    default:
      os.put('x');
      os.put(((c & 0xF0 >> 8)+'0'));
      os.put(((c & 0x0F)+'0'));
      ;
      }
  }
  
  os.put('\'');

  return os;
}

std::istream& operator>>(std::istream& is, Char& c)
{
  char cc;
  is.get(cc);
  
  is.get(c);
  
  if (c == '\\') {
    char c2;
    is.get(c2);
    switch(c2) {

    case '\'':
      c= '\'';
      break;

    case '\\':
      c= '\\';
      break;
      
    case 'a':
      c = '\a';
      break;
        
    case 'b':
      c = '\b';
      break;

    case 'f':
      c = '\f';
      break;
      
    case '0':
      c = '\0';
      break;

    case 'n':
      c = '\n';
      break;
      
    case 'r':
      c = '\r';
      break;
 
    case 't':
      c = '\t';
      break;
    case 'v':
      c = '\v';
      break;
      
    case 'x':
      char l_c1;
      char l_c2;
      
      is.get(l_c1);
      is.get(l_c2);

      c = (l_c1-'0') << 8 + (l_c2-'0');
      break;

    }
      
  }
  is.get(cc);

  return is;
}
