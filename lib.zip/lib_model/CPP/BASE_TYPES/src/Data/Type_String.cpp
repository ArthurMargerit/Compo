#include "Data/Type_String.hpp"

std::ostream& operator<<(std::ostream& os, const String& c)
{
  os.put('"');
  for(auto i_c : c){

    if(i_c == '"')
      os.put('\\');

    os.put(i_c);
  }
  os.put('"');

  return os;
}

std::istream& operator>>(std::istream& is, String& c)
{
  char cc;
  is.get(cc);
  std::getline(is, c, '"');


  return is;
}
