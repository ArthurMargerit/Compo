#define CATCH_CONFIG_MAIN
#include "test/catch.hpp"
#include <iostream>
#include <sstream>
#include "Data/base_types.hpp"


TEST_CASE( "types_size", "[Types]" ) {
  REQUIRE( sizeof(ui8) == 1 );
  REQUIRE( sizeof(i8) == 1 );

  REQUIRE( sizeof(i16) == 2 );
  REQUIRE( sizeof(ui16) == 2 );

  REQUIRE( sizeof(i32) == 4 );
  REQUIRE( sizeof(ui32) == 4 );

  REQUIRE( sizeof(i64) == 8 );
  REQUIRE( sizeof(ui64) == 8 );
}

TEST_CASE( "int to_str() -> from_str()", "[Types]" ) {
  std::stringstream ss1;
  auto v = GENERATE(1,2,4,5,-5,6,4);
  auto r_v = 0;
  ss1 << v;
  ss1 >> r_v;
  REQUIRE(r_v == v);
}

TEST_CASE( "String Serialisation", "[Types][String]" ) {
  std::stringstream ss2;
  String s = GENERATE(String("string"),String(""),String("aea\"lapin\""));
  String r_s = "";

  SECTION("One") {
    ss2 << s;
    ss2 >> r_s;
    REQUIRE(r_s == s);
  }
  
  SECTION("Two") {
    // one
    ss2 << s;
    ss2 >> r_s;
    REQUIRE(r_s == s);
    
    r_s = "";
    // two
    ss2 << s;
    ss2 >> r_s;
    REQUIRE(r_s == s);
  }
  
  SECTION("N"){
    for(int a = 0; a < 100; a++) {
      // step
      r_s = "";
      ss2 << s;
      ss2 >> r_s;
      REQUIRE(r_s == s);
    }
  }  
}

TEST_CASE( "Char Serialisation", "[Types][Char]" ) {
  std::stringstream ss2;
  Char s = GENERATE(' ','q','b','b','a','"','\'','\\','\n','\r');
  Char r_s = ' ';

  SECTION("one") {
    ss2 << s;
    ss2 >> r_s;
    REQUIRE( r_s == s );
  }
}

TEST_CASE( "Char all Serialisation", "[Types][Char]" ) {
  std::stringstream ss2;
  SECTION("one") {
    for(int i=0;i<256;i++){
      Char l_c= (Char)(i);
      ss2 << l_c;
    }
    
    for(int i=0;i<256;i++){
      Char l_c_t= (Char)(i);
      Char l_c = 'U';
      std::cout << ss2.str() << std::endl;
      ss2 >> l_c;
      REQUIRE(l_c == l_c_t);
    }          
  }
  
  // SECTION("Two") {
  //   ss2 << s;
  //   ss2 >> r_s;
  //   REQUIRE(r_s == s);
  //   r_s = ' ';
  //   ss2 >> r_s;
  //   REQUIRE(r_s == s);
  // }
}

