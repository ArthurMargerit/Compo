#include "Links/Link.hpp"

Link::Link() {}

Link::~Link() {}