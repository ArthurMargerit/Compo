#include "Interfaces/Fake.hpp"

Fake::Fake(Function_stream &p_o, Return_stream &p_i) : o(p_o), i(p_i) {}

Fake::~Fake() {}
