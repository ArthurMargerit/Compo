HOME = "/home/g179923/p"

CONFIG = {
    "migration": "",
    "import_path": ["."],
    "generation_model": HOME+"/compo/generate_model/CPP/out2.yaml",
    "jinja_template_path": [HOME+"/compo/generate_model/CPP/"],
    "template_options":{"project":{"name":"base"}}
}
