#include "Data/Struct_Range.hpp"
#include <iostream>

#include <istream>
#include <ostream>

std::ostream &operator<<(std::ostream &os, const Range *c) {
  os << (Struct *)c;
  return os;
}

std::istream &operator>>(std::istream &is, Range *&c) {
  std::string t = get_type(is);
  if (t != "Range"

      && t != "Range_R_s"

      && t != "Range_Z_s"

      ) {
    std::cerr << "ERR: TYPE ERROR\n"
              << "\t" << t << " is not a <Range>\n";

    std::cerr << "\t" << t
              << " is not one of child type {'Range_R_s', 'Range_Z_s'}\n";
  }
  is >> (Struct *&)c;
  return is;
}

std::ostream &operator<<(std::ostream &os, const Range &c) {
  os << "{"
     << "type:"
     << "Range,"
     << "}";
  return os;
}

std::istream &operator>>(std::istream &is, Range &c) {
  is.ignore(100, '{');
  std::string type;
  is.ignore(100, ':');
  std::getline(is, type, ',');
  if (type != "Range") {
    std::cerr << "ERREUR TYPE:"
              << ">Range< != >" << type << "<" << std::endl;
  }

  is.ignore(1, '}');

  return is;
}

Range::Range()

{}
void Range::next() { return; }

void Range::reset() { return; }

void Range::is_end() { return; }

ui32 Range::is_valid() { return 0; }

ui32 Range::size() { return 0; }

ui32 Range::step_number() { return 0; }

void Range::to_stream(std::ostream &os) const { os << *this; }