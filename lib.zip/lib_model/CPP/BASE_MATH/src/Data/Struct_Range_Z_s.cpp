#include "Data/Struct_Range_Z_s.hpp"
#include <iostream>

#include <istream>
#include <ostream>

std::ostream &operator<<(std::ostream &os, const Range_Z_s *c) {
  os << (Struct *)c;
  return os;
}

std::istream &operator>>(std::istream &is, Range_Z_s *&c) {
  std::string t = get_type(is);
  if (t != "Range_Z_s"

      ) {
    std::cerr << "ERR: TYPE ERROR\n"
              << "\t" << t << " is not a <Range_Z_s>\n";
  }
  is >> (Struct *&)c;
  return is;
}

std::ostream &operator<<(std::ostream &os, const Range_Z_s &c) {
  os << "{"
     << "type:"
     << "Range_Z_s,"
     << "parrent:" << (Range)c << ","
     << "start:" << c.start << ","
     << "position:" << c.position << ","
     << "end:" << c.end << ","
     << "step:" << c.step << "}";
  return os;
}

std::istream &operator>>(std::istream &is, Range_Z_s &c) {
  is.ignore(100, '{');
  std::string type;
  is.ignore(100, ':');
  std::getline(is, type, ',');
  if (type != "Range_Z_s") {
    std::cerr << "ERREUR TYPE:"
              << ">Range_Z_s< != >" << type << "<" << std::endl;
  }
  is.ignore(100, ':') >> (Range &)c;
  is.ignore(100, ':') >> c.start;
  is.ignore(1, ',');
  is.ignore(100, ':') >> c.position;
  is.ignore(1, ',');
  is.ignore(100, ':') >> c.end;
  is.ignore(1, ',');
  is.ignore(100, ':') >> c.step;
  is.ignore(1, '}');

  return is;
}

Range_Z_s::Range_Z_s(i32 p_start, i32 p_position, i32 p_end, i32 p_step)
    : start(p_start), position(p_position), end(p_end), step(p_step) {}

Range_Z_s::Range_Z_s() : start(0), position(0), end(0), step(0) {}
i32 Range_Z_s::get_start() const { return this->start; }

void Range_Z_s::set_start(const i32 value) { this->start = value; }
i32 Range_Z_s::get_position() const { return this->position; }

void Range_Z_s::set_position(const i32 value) { this->position = value; }
i32 Range_Z_s::get_end() const { return this->end; }

void Range_Z_s::set_end(const i32 value) { this->end = value; }
i32 Range_Z_s::get_step() const { return this->step; }

void Range_Z_s::set_step(const i32 value) { this->step = value; }

void Range_Z_s::next() { return; }

void Range_Z_s::reset() { return; }

void Range_Z_s::is_end() { return; }

ui32 Range_Z_s::is_valid() { return 0; }

ui32 Range_Z_s::size() { return 0; }

ui32 Range_Z_s::step_number() { return 0; }

void Range_Z_s::to_stream(std::ostream &os) const { os << *this; }