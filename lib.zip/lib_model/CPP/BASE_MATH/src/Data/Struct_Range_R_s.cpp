#include "Data/Struct_Range_R_s.hpp"
#include <iostream>

#include <istream>
#include <ostream>

std::ostream &operator<<(std::ostream &os, const Range_R_s *c) {
  os << (Struct *)c;
  return os;
}

std::istream &operator>>(std::istream &is, Range_R_s *&c) {
  std::string t = get_type(is);
  if (t != "Range_R_s"

      ) {
    std::cerr << "ERR: TYPE ERROR\n"
              << "\t" << t << " is not a <Range_R_s>\n";
  }
  is >> (Struct *&)c;
  return is;
}

std::ostream &operator<<(std::ostream &os, const Range_R_s &c) {
  os << "{"
     << "type:"
     << "Range_R_s,"
     << "parrent:" << (Range)c << ","
     << "position:" << c.position << ","
     << "start:" << c.start << ","
     << "end:" << c.end << ","
     << "step:" << c.step << "}";
  return os;
}

std::istream &operator>>(std::istream &is, Range_R_s &c) {
  is.ignore(100, '{');
  std::string type;
  is.ignore(100, ':');
  std::getline(is, type, ',');
  if (type != "Range_R_s") {
    std::cerr << "ERREUR TYPE:"
              << ">Range_R_s< != >" << type << "<" << std::endl;
  }
  is.ignore(100, ':') >> (Range &)c;
  is.ignore(100, ':') >> c.position;
  is.ignore(1, ',');
  is.ignore(100, ':') >> c.start;
  is.ignore(1, ',');
  is.ignore(100, ':') >> c.end;
  is.ignore(1, ',');
  is.ignore(100, ':') >> c.step;
  is.ignore(1, '}');

  return is;
}

Range_R_s::Range_R_s(double p_position, double p_start, double p_end,
                     double p_step)
    : position(p_position), start(p_start), end(p_end), step(p_step) {}

Range_R_s::Range_R_s() : position(0.0), start(0.0), end(0.0), step(0.0) {}
double Range_R_s::get_position() const { return this->position; }

void Range_R_s::set_position(const double value) { this->position = value; }
double Range_R_s::get_start() const { return this->start; }

void Range_R_s::set_start(const double value) { this->start = value; }
double Range_R_s::get_end() const { return this->end; }

void Range_R_s::set_end(const double value) { this->end = value; }
double Range_R_s::get_step() const { return this->step; }

void Range_R_s::set_step(const double value) { this->step = value; }

void Range_R_s::next() { return; }

void Range_R_s::reset() { return; }

void Range_R_s::is_end() { return; }

ui32 Range_R_s::is_valid() { return 0; }

ui32 Range_R_s::size() { return 0; }

ui32 Range_R_s::step_number() { return 0; }

void Range_R_s::to_stream(std::ostream &os) const { os << *this; }