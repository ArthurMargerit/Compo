#pragma once

#include <ostream>

#include "Data/base_math.hpp"

#include "Data/Struct_Range.hpp"

struct Range_R_s : public Range {

  /////////////////////////////////////////////////////////////////////////////
  //                                ATTRIBURE                                //
  /////////////////////////////////////////////////////////////////////////////
  double position;
  double start;
  double end;
  double step;

  /////////////////////////////////////////////////////////////////////////////
  //                               CONSTRUCTEUR                              //
  /////////////////////////////////////////////////////////////////////////////
  Range_R_s();

  Range_R_s(double p_position, double p_start, double p_end, double p_step);

  /////////////////////////////////////////////////////////////////////////////
  //                               GET and SET                               //
  /////////////////////////////////////////////////////////////////////////////
  double get_position() const;

  void set_position(const double value);
  double get_start() const;

  void set_start(const double value);
  double get_end() const;

  void set_end(const double value);
  double get_step() const;

  void set_step(const double value);

  /////////////////////////////////////////////////////////////////////////////
  //                               FUNCTION                                  //
  /////////////////////////////////////////////////////////////////////////////

  virtual void next();
  virtual void reset();
  virtual void is_end();
  virtual ui32 is_valid();
  virtual ui32 size();
  virtual ui32 step_number();

  virtual void to_stream(std::ostream &) const;
};

///////////////////////////////////////////////////////////////////////////////
//                               << STREAM >>                                //
///////////////////////////////////////////////////////////////////////////////
std::ostream &operator<<(std::ostream &os, const Range_R_s &c);
std::istream &operator>>(std::istream &os, Range_R_s &c);

std::ostream &operator<<(std::ostream &os, const Range_R_s *c);
std::istream &operator>>(std::istream &os, Range_R_s *&c);
