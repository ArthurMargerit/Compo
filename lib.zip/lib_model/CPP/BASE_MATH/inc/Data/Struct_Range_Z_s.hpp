#pragma once

#include <ostream>

#include "Data/base_math.hpp"

#include "Data/Struct_Range.hpp"

struct Range_Z_s : public Range {

  /////////////////////////////////////////////////////////////////////////////
  //                                ATTRIBURE                                //
  /////////////////////////////////////////////////////////////////////////////
  i32 start;
  i32 position;
  i32 end;
  i32 step;

  /////////////////////////////////////////////////////////////////////////////
  //                               CONSTRUCTEUR                              //
  /////////////////////////////////////////////////////////////////////////////
  Range_Z_s();

  Range_Z_s(i32 p_start, i32 p_position, i32 p_end, i32 p_step);

  /////////////////////////////////////////////////////////////////////////////
  //                               GET and SET                               //
  /////////////////////////////////////////////////////////////////////////////
  i32 get_start() const;

  void set_start(const i32 value);
  i32 get_position() const;

  void set_position(const i32 value);
  i32 get_end() const;

  void set_end(const i32 value);
  i32 get_step() const;

  void set_step(const i32 value);

  /////////////////////////////////////////////////////////////////////////////
  //                               FUNCTION                                  //
  /////////////////////////////////////////////////////////////////////////////

  virtual void next();
  virtual void reset();
  virtual void is_end();
  virtual ui32 is_valid();
  virtual ui32 size();
  virtual ui32 step_number();

  virtual void to_stream(std::ostream &) const;
};

///////////////////////////////////////////////////////////////////////////////
//                               << STREAM >>                                //
///////////////////////////////////////////////////////////////////////////////
std::ostream &operator<<(std::ostream &os, const Range_Z_s &c);
std::istream &operator>>(std::istream &os, Range_Z_s &c);

std::ostream &operator<<(std::ostream &os, const Range_Z_s *c);
std::istream &operator>>(std::istream &os, Range_Z_s *&c);
