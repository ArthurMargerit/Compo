#include "Links/Direct/Direct.hpp"

Direct::Direct() {}

Direct::~Direct() {}

void Direct::set_from_to(Interface **pfrom, Interface *pto) {}

void Direct::step() {}

void Direct::connect() {}

void Direct::disconnect() {}

// Get and set /////////////////////////////////////////////////////////////
