#include "Links/Indirect/Indirect.hpp"

Indirect::Indirect() {}

Indirect::~Indirect() {}

void Indirect::set_from_to(Interface **pfrom, Interface *pto) {}

void Indirect::step() {}

void Indirect::connect() {}

void Indirect::disconnect() {}

// Get and set /////////////////////////////////////////////////////////////
