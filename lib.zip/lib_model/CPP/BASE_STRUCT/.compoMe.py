HOME = "/home/g179923/p"

CONFIG = {
    "migration": "git",
    "import_path": [".","../BASE","../BASE_TYPES"],
    "generation_model": HOME+"/compo/generate_model/CPP/out2.yaml",
    "jinja_template_path": [HOME+"/compo/generate_model/CPP/"],
    "template_options":{"project":{"name":"base_structs"}}
}
