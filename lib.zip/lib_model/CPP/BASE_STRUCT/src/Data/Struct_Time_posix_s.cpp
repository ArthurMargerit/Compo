#include "Data/Struct_Time_posix_s.hpp"
#include <iostream>

#include <istream>
#include <ostream>

std::ostream &operator<<(std::ostream &os, const Time_posix_s *c) {
  os << (Struct *)c;
  return os;
}

std::istream &operator>>(std::istream &is, Time_posix_s *&c) {
  std::string t = get_type(is);
  if (t != "Time_posix_s"

      ) {
    std::cerr << "ERR: TYPE ERROR\n"
              << "\t" << t << " is not a <Time_posix_s>\n";
  }
  is >> (Struct *&)c;
  return is;
}

std::ostream &operator<<(std::ostream &os, const Time_posix_s &c) {
  os << "{"
     << "type:"
     << "Time_posix_s,"
     << "parrent:" << (Time_s)c << ","
     << "posix_time:" << c.posix_time << "}";
  return os;
}

std::istream &operator>>(std::istream &is, Time_posix_s &c) {
  is.ignore(100, '{');
  std::string type;
  is.ignore(100, ':');
  std::getline(is, type, ',');
  if (type != "Time_posix_s") {
    std::cerr << "ERREUR TYPE:"
              << ">Time_posix_s< != >" << type << "<" << std::endl;
  }
  is.ignore(100, ':') >> (Time_s &)c;
  is.ignore(100, ':') >> c.posix_time;
  is.ignore(1, '}');

  return is;
}

Time_posix_s::Time_posix_s(ui64 p_posix_time) : posix_time(p_posix_time) {}

Time_posix_s::Time_posix_s() : posix_time(0) {}
ui64 Time_posix_s::get_posix_time() const { return this->posix_time; }

void Time_posix_s::set_posix_time(const ui64 value) {
  this->posix_time = value;
}

ui64 Time_posix_s::get_secs() { return 0; }

ui64 Time_posix_s::get_mins() { return 0; }

ui64 Time_posix_s::get_hours() { return 0; }

ui64 Time_posix_s::get_days() { return 0; }

ui64 Time_posix_s::get_months() { return 0; }

ui64 Time_posix_s::get_years() { return 0; }

void Time_posix_s::to_stream(std::ostream &os) const { os << *this; }