#pragma once

#include <ostream>

#include "Data/base_structs.hpp"

#include "Data/Struct_Time_s.hpp"

struct Time_posix_s : public Time_s {

  /////////////////////////////////////////////////////////////////////////////
  //                                ATTRIBURE                                //
  /////////////////////////////////////////////////////////////////////////////
  ui64 posix_time;

  /////////////////////////////////////////////////////////////////////////////
  //                               CONSTRUCTEUR                              //
  /////////////////////////////////////////////////////////////////////////////
  Time_posix_s();

  Time_posix_s(ui64 p_posix_time);

  /////////////////////////////////////////////////////////////////////////////
  //                               GET and SET                               //
  /////////////////////////////////////////////////////////////////////////////
  ui64 get_posix_time() const;

  void set_posix_time(const ui64 value);

  /////////////////////////////////////////////////////////////////////////////
  //                               FUNCTION                                  //
  /////////////////////////////////////////////////////////////////////////////

  virtual ui64 get_secs();
  virtual ui64 get_mins();
  virtual ui64 get_hours();
  virtual ui64 get_days();
  virtual ui64 get_months();
  virtual ui64 get_years();

  virtual void to_stream(std::ostream &) const;
};

///////////////////////////////////////////////////////////////////////////////
//                               << STREAM >>                                //
///////////////////////////////////////////////////////////////////////////////
std::ostream &operator<<(std::ostream &os, const Time_posix_s &c);
std::istream &operator>>(std::istream &os, Time_posix_s &c);

std::ostream &operator<<(std::ostream &os, const Time_posix_s *c);
std::istream &operator>>(std::istream &os, Time_posix_s *&c);
